import {Component, NgModule} from '@angular/core';
import {Routes, RouterModule} from '@angular/router';

import {AdminComponent} from './components/admin/admin.component';


import {LightComponent} from './template-components/dashboard/light/light.component';
import {DarkComponent} from './template-components/dashboard/dark/dark.component';

import {OrdersListComponent} from './template-components/orders-list/orders-list.component';
import {OrderDetailComponent} from './template-components/order-detail/order-detail.component';
import {CustomersComponent} from './template-components/customers/customers.component';
import {AnalyticsComponent} from './template-components/analytics/analytics.component';
import {ReviewsComponent} from './template-components/reviews/reviews.component';


import {ProfileComponent} from './template-components/apps/profile/profile.component';
import {PostDetailsComponent} from './template-components/apps/post-details/post-details.component';
import {ComposeComponent} from './template-components/apps/email/compose/compose.component';
import {InboxComponent} from './template-components/apps/email/inbox/inbox.component';
import {ReadComponent} from './template-components/apps/email/read/read.component';
import {CalenderComponent} from './template-components/apps/calender/calender.component';
import {ProductGridComponent} from './template-components/apps/shop/product-grid/product-grid.component';
import {ProductListComponent} from './template-components/apps/shop/product-list/product-list.component';
import {ProductDetailComponent} from './template-components/apps/shop/product-detail/product-detail.component';
import {OrderComponent} from './template-components/apps/shop/order/order.component';
import {CheckoutComponent} from './template-components/apps/shop/checkout/checkout.component';
import {InvoiceComponent} from './template-components/apps/shop/invoice/invoice.component';
import {EcomCustomersComponent} from './template-components/apps/shop/ecom-customers/ecom-customers.component';

import {ApexComponent} from './template-components/charts/apex/apex.component';
import {LineComponent} from './template-components/charts/apex/line/line.component';
import {AreaComponent} from './template-components/charts/apex/area/area.component';
import {ColumnComponent} from './template-components/charts/apex/column/column.component';
import {BarComponent} from './template-components/charts/apex/bar/bar.component';
import {MixedComponent} from './template-components/charts/apex/mixed/mixed.component';
import {TimelineComponent} from './template-components/charts/apex/timeline/timeline.component';
import {CandlestickComponent} from './template-components/charts/apex/candlestick/candlestick.component';
import {PieComponent} from './template-components/charts/apex/pie/pie.component';
import {RadarComponent} from './template-components/charts/apex/radar/radar.component';
import {RadialbarComponent} from './template-components/charts/apex/radialbar/radialbar.component';
import {PolarAreaComponent} from './template-components/charts/apex/polar-area/polar-area.component';
import {BubbleComponent} from './template-components/charts/apex/bubble/bubble.component';
import {ScatterComponent} from './template-components/charts/apex/scatter/scatter.component';
import {HeatmapComponent} from './template-components/charts/apex/heatmap/heatmap.component';
import {TreemapComponent} from './template-components/charts/apex/treemap/treemap.component';
import {SparklinesComponent} from './template-components/charts/apex/sparklines/sparklines.component';
import {ChartjsComponent} from './template-components/charts/chartjs/chartjs.component';


import {AccordionComponent} from './template-components/bootstrap/accordion/accordion.component';
import {AlertComponent} from './template-components/bootstrap/alert/alert.component';
import {ButtonComponent} from './template-components/bootstrap/button/button.component';
import {ModalComponent} from './template-components/bootstrap/modal/modal.component';
import {BadgeComponent} from './template-components/bootstrap/badge/badge.component';
import {ButtonGroupComponent} from './template-components/bootstrap/button-group/button-group.component';
import {ListGroupComponent} from './template-components/bootstrap/list-group/list-group.component';
import {CardsComponent} from './template-components/bootstrap/cards/cards.component';
import {CarouselComponent} from './template-components/bootstrap/carousel/carousel.component';
import {DatepickerComponent} from './template-components/bootstrap/datepicker/datepicker.component';
import {DropdownComponent} from './template-components/bootstrap/dropdown/dropdown.component';
import {MediaObjectComponent} from './template-components/bootstrap/media-object/media-object.component';
import {NavComponent} from './template-components/bootstrap/nav/nav.component';
import {PaginationComponent} from './template-components/bootstrap/pagination/pagination.component';
import {PopoverComponent} from './template-components/bootstrap/popover/popover.component';
import {ProgressbarComponent} from './template-components/bootstrap/progressbar/progressbar.component';
import {RatingComponent} from './template-components/bootstrap/rating/rating.component';
import {TableComponent} from './template-components/bootstrap/table/table.component';
import {TimepickerComponent} from './template-components/bootstrap/timepicker/timepicker.component';
import {ToastComponent} from './template-components/bootstrap/toast/toast.component';
import {TooltipComponent} from './template-components/bootstrap/tooltip/tooltip.component';
import {TypeaheadComponent} from './template-components/bootstrap/typeahead/typeahead.component';
import {TypographyComponent} from './template-components/bootstrap/typography/typography.component';
import {GridComponent} from './template-components/bootstrap/grid/grid.component';


import {DzmtAutocompleteComponent} from './template-components/material/dzmt-autocomplete/dzmt-autocomplete.component';
import {DzmtBadgeComponent} from './template-components/material/dzmt-badge/dzmt-badge.component';
import {DzmtBottomSheetComponent} from './template-components/material/dzmt-bottom-sheet/dzmt-bottom-sheet.component';
import {DzmtButtonComponent} from './template-components/material/dzmt-button/dzmt-button.component';
import {
  DzmtButtonToggleComponent
} from './template-components/material/dzmt-button-toggle/dzmt-button-toggle.component';
import {DzmtCardComponent} from './template-components/material/dzmt-card/dzmt-card.component';
import {DzmtCheckboxComponent} from './template-components/material/dzmt-checkbox/dzmt-checkbox.component';
import {DzmtChipsComponent} from './template-components/material/dzmt-chips/dzmt-chips.component';
import {DzmtDatepickerComponent} from './template-components/material/dzmt-datepicker/dzmt-datepicker.component';
import {DzmtDialogComponent} from './template-components/material/dzmt-dialog/dzmt-dialog.component';
import {DzmtDividerComponent} from './template-components/material/dzmt-divider/dzmt-divider.component';
import {DzmtExpansionComponent} from './template-components/material/dzmt-expansion/dzmt-expansion.component';
import {DzmtFormFieldComponent} from './template-components/material/dzmt-form-field/dzmt-form-field.component';
import {DzmtGridListComponent} from './template-components/material/dzmt-grid-list/dzmt-grid-list.component';
import {DzmtIconComponent} from './template-components/material/dzmt-icon/dzmt-icon.component';
import {DzmtInputComponent} from './template-components/material/dzmt-input/dzmt-input.component';
import {DzmtListComponent} from './template-components/material/dzmt-list/dzmt-list.component';
import {DzmtMenuComponent} from './template-components/material/dzmt-menu/dzmt-menu.component';
import {DzmtPaginatorComponent} from './template-components/material/dzmt-paginator/dzmt-paginator.component';
import {DzmtProgressBarComponent} from './template-components/material/dzmt-progress-bar/dzmt-progress-bar.component';
import {
  DzmtProgressSpinnerComponent
} from './template-components/material/dzmt-progress-spinner/dzmt-progress-spinner.component';
import {DzmtRadioComponent} from './template-components/material/dzmt-radio/dzmt-radio.component';
import {DzmtRippleComponent} from './template-components/material/dzmt-ripple/dzmt-ripple.component';
import {DzmtSelectComponent} from './template-components/material/dzmt-select/dzmt-select.component';
import {DzmtSidenavComponent} from './template-components/material/dzmt-sidenav/dzmt-sidenav.component';
import {DzmtSlideToggleComponent} from './template-components/material/dzmt-slide-toggle/dzmt-slide-toggle.component';
import {DzmtSliderComponent} from './template-components/material/dzmt-slider/dzmt-slider.component';
import {DzmtSnackBarComponent} from './template-components/material/dzmt-snack-bar/dzmt-snack-bar.component';
import {DzmtSortComponent} from './template-components/material/dzmt-sort/dzmt-sort.component';
import {DzmtStepperComponent} from './template-components/material/dzmt-stepper/dzmt-stepper.component';
import {DzmtTableComponent} from './template-components/material/dzmt-table/dzmt-table.component';
import {DzmtTabsComponent} from './template-components/material/dzmt-tabs/dzmt-tabs.component';
import {DzmtTooltipComponent} from './template-components/material/dzmt-tooltip/dzmt-tooltip.component';
import {DzmtTreeComponent} from './template-components/material/dzmt-tree/dzmt-tree.component';
import {DzmtToolbarComponent} from './template-components/material/dzmt-toolbar/dzmt-toolbar.component';


import {NestableComponent} from './template-components/plugins/nestable/nestable.component';
import {LightGalleryComponent} from './template-components/plugins/light-gallery/light-gallery.component';

import {WidgetComponent} from './template-components/widget/widget.component';


import {ElementsComponent} from './template-components/forms/elements/elements.component';
import {FormValidateComponent} from './template-components/forms/form-validate/form-validate.component';


import {RegisterComponent} from './components/register/register.component';
import {LoginComponent} from './components/login/login.component';
import {Login2Component} from './template-components/pages/login2/login2.component';
import {LockScreenComponent} from './template-components/pages/lock-screen/lock-screen.component';
import {ForgotPasswordComponent} from './template-components/pages/forgot-password/forgot-password.component';
import {Error400Component} from './template-components/pages/error400/error400.component';
import {Error403Component} from './template-components/pages/error403/error403.component';
import {Error404Component} from './template-components/pages/error404/error404.component';
import {Error500Component} from './template-components/pages/error500/error500.component';
import {Error503Component} from './template-components/pages/error503/error503.component';
import {AuthenticationGuard} from "./helpers/authentication.guard";
import {RoleGuard} from "./helpers/role.guard";
import {AddProductComponent} from './components/add-product/add-product.component';
import {HomeComponent} from "./components/home/home.component";
import {MenuComponent} from "./components/menu/menu.component";
import {AddPhotoComponent} from './components/add-photo/add-photo.component';
import {AddInteractionComponent} from './components/add-interaction/add-interaction.component';
import {ShowInteractionComponent} from './components/show-interaction/show-interaction.component';
import {ShowMyreservationComponent} from './components/show-myreservation/show-myreservation.component';
import {OrdersComponent} from './components/orders/orders.component';

import {ShowAllReservationsComponent} from './components/show-all-reservations/show-all-reservations.component';
import {ProductsComponent} from './components/products/products.component';
import {AddMenuComponent} from './components/add-menu/add-menu.component';
import {OrderProductComponent} from './components/order-product/order-product.component';
import {EmailresponseComponent} from './components/emailresponse/emailresponse.component';
import {ProductDetailsComponent} from './components/product-details/product-details.component';
import {EditProductComponent} from './components/edit-product/edit-product.component';
import {AllOrdersComponent} from './components/all-orders/all-orders.component';
import {AuthGuard} from "./helpers/auth.guard";
import { EditMenuItemComponent } from './components/edit-menu-item/edit-menu-item.component';


const routes: Routes = [
  {path: '', redirectTo: '/index', pathMatch: 'full'},
  {
    path: '', component: AdminComponent, children: [
      {path: 'products', component: OrderProductComponent},
      {path: 'products/:id', component: ProductDetailsComponent},
      {path: 'index', component: HomeComponent},
      {path: 'menu', component: MenuComponent},
      {
        path: 'getReservationByUserId',
        component: ShowMyreservationComponent,
        canActivate: [AuthenticationGuard, RoleGuard],
        data: {role: 'USER'}
      },
      {
        path: 'addIntercation',
        component: AddInteractionComponent,
        canActivate: [AuthenticationGuard, RoleGuard],
        data: {role: 'USER'}
      },
      {
        path: 'ordersreservation/:id',
        component: OrdersComponent,
        canActivate: [AuthenticationGuard, RoleGuard],
        data: {role: 'USER'}
      },
    ]
  },
  {
    path: 'admin',
    component: AdminComponent,
    canActivate: [AuthenticationGuard, RoleGuard],
    data: {role: 'ADMIN'},
    children: [

      {path: 'addproduct/:origin/:id', component: AddProductComponent},
      {path: 'products/:id', component: EditProductComponent},
      {path: '', component: LightComponent},
      {path: 'showIntercation', component: ShowInteractionComponent},
      {path: 'allreservation', component: ShowAllReservationsComponent},
      {path: 'emailresponse/:id', component: EmailresponseComponent},
      {path: 'products', component: ProductsComponent},
      {path: 'add-menu', component: AddMenuComponent},
      {path: 'menu-item/:id', component: EditMenuItemComponent},

      {path: 'index', component: LightComponent},
      {path: 'index-1', component: LightComponent},
      {path: 'dashboard', component: LightComponent},
      {path: 'index-2', component: DarkComponent},
      {path: 'dashboard-2', component: DarkComponent},
      {path: 'orders-list', component: OrdersListComponent},
      {path: 'order-detail', component: OrderDetailComponent},
      {path: 'customer-list', component: CustomersComponent},
      {path: 'analytics', component: AnalyticsComponent},
      {path: 'reviews', component: ReviewsComponent},

      {path: 'app-profile', component: ProfileComponent},
      {path: 'post-details', component: PostDetailsComponent},
      {path: 'email-compose', component: ComposeComponent},
      {path: 'email-inbox', component: InboxComponent},
      {path: 'email-read', component: ReadComponent},
      {path: 'app-calender', component: CalenderComponent},

      {path: 'ecom-product-grid', component: ProductGridComponent},
      {path: 'ecom-product-list', component: ProductListComponent},
      {path: 'ecom-product-detail', component: ProductDetailComponent},
      {path: 'ecom-product-order', component: OrderComponent},
      {path: 'ecom-checkout', component: CheckoutComponent},
      {path: 'ecom-invoice', component: InvoiceComponent},
      {path: 'ecom-customers', component: EcomCustomersComponent},

      {path: 'chart-apex', component: ApexComponent},
      {path: 'apex-line', component: LineComponent},
      {path: 'apex-area', component: AreaComponent},
      {path: 'apex-column', component: ColumnComponent},
      {path: 'apex-bar', component: BarComponent},
      {path: 'apex-mixed', component: MixedComponent},
      {path: 'apex-timeline', component: TimelineComponent},
      {path: 'apex-candlestick', component: CandlestickComponent},
      {path: 'apex-pie', component: PieComponent},
      {path: 'apex-radar', component: RadarComponent},
      {path: 'apex-radialbar', component: RadialbarComponent},
      {path: 'apex-polar-area', component: PolarAreaComponent},
      {path: 'apex-bubble', component: BubbleComponent},
      {path: 'apex-scatter', component: ScatterComponent},
      {path: 'apex-heatmap', component: HeatmapComponent},
      {path: 'apex-treemap', component: TreemapComponent},
      {path: 'apex-sparklines', component: SparklinesComponent},
      {path: 'chart-chartjs', component: ChartjsComponent},


      {path: 'ui-accordion', component: AccordionComponent},
      {path: 'ui-alert', component: AlertComponent},
      {path: 'ui-button', component: ButtonComponent},
      {path: 'ui-modal', component: ModalComponent},
      {path: 'ui-badge', component: BadgeComponent},
      {path: 'ui-button-group', component: ButtonGroupComponent},
      {path: 'ui-list-group', component: ListGroupComponent},
      {path: 'ui-card', component: CardsComponent},
      {path: 'ui-carousel', component: CarouselComponent},
      {path: 'ui-datepicker', component: DatepickerComponent},
      {path: 'ui-dropdown', component: DropdownComponent},
      {path: 'ui-media-object', component: MediaObjectComponent},
      {path: 'ui-nav', component: NavComponent},
      {path: 'ui-pagination', component: PaginationComponent},
      {path: 'ui-popover', component: PopoverComponent},
      {path: 'ui-progressbar', component: ProgressbarComponent},
      {path: 'ui-rating', component: RatingComponent},
      {path: 'ui-table', component: TableComponent},
      {path: 'ui-timepicker', component: TimepickerComponent},
      {path: 'ui-toast', component: ToastComponent},
      {path: 'ui-tooltip', component: TooltipComponent},
      {path: 'ui-typeahead', component: TypeaheadComponent},
      {path: 'ui-typography', component: TypographyComponent},
      {path: 'ui-grid', component: GridComponent},


      {path: 'mat-autocomplete', component: DzmtAutocompleteComponent},
      {path: 'mat-badge', component: DzmtBadgeComponent},
      {path: 'mat-bottom-sheet', component: DzmtBottomSheetComponent},
      {path: 'mat-button', component: DzmtButtonComponent},
      {path: 'mat-button-toggle', component: DzmtButtonToggleComponent},
      {path: 'mat-card', component: DzmtCardComponent},
      {path: 'mat-checkbox', component: DzmtCheckboxComponent},
      {path: 'mat-chips', component: DzmtChipsComponent},
      {path: 'mat-datepicker', component: DzmtDatepickerComponent},
      {path: 'mat-dialog', component: DzmtDialogComponent},
      {path: 'mat-divider', component: DzmtDividerComponent},
      {path: 'mat-expansion', component: DzmtExpansionComponent},
      {path: 'mat-form-field', component: DzmtFormFieldComponent},
      {path: 'mat-grid-list', component: DzmtGridListComponent},
      {path: 'mat-icon', component: DzmtIconComponent},
      {path: 'mat-input', component: DzmtInputComponent},
      {path: 'mat-list', component: DzmtListComponent},
      {path: 'mat-menu', component: DzmtMenuComponent},
      {path: 'mat-paginator', component: DzmtPaginatorComponent},
      {path: 'mat-progress-bar', component: DzmtProgressBarComponent},
      {path: 'mat-progress-spinner', component: DzmtProgressSpinnerComponent},
      {path: 'mat-radio', component: DzmtRadioComponent},
      {path: 'mat-ripple', component: DzmtRippleComponent},
      {path: 'mat-select', component: DzmtSelectComponent},
      {path: 'mat-sidenav', component: DzmtSidenavComponent},
      {path: 'mat-slide-toggle', component: DzmtSlideToggleComponent},
      {path: 'mat-slider', component: DzmtSliderComponent},
      {path: 'mat-snack-bar', component: DzmtSnackBarComponent},
      {path: 'mat-sort', component: DzmtSortComponent},
      {path: 'mat-stepper', component: DzmtStepperComponent},
      {path: 'mat-table', component: DzmtTableComponent},
      {path: 'mat-tab', component: DzmtTabsComponent},
      {path: 'mat-tooltip', component: DzmtTooltipComponent},
      {path: 'mat-tree', component: DzmtTreeComponent},
      {path: 'mat-toolbar', component: DzmtToolbarComponent},

      {path: 'uc-nestable', component: NestableComponent},
      {path: 'uc-lightgallery', component: LightGalleryComponent},

      {path: 'widget-basic', component: WidgetComponent},

      {path: 'form-element', component: ElementsComponent},
      {path: 'form-validate', component: FormValidateComponent},


    ]
  },


  {path: 'page-register', component: RegisterComponent, canActivate:  [AuthGuard]},
  {path: 'page-login', component: LoginComponent, canActivate:  [AuthGuard]},
  {path: 'login', component: Login2Component},
  {path: 'page-lock-screen', component: LockScreenComponent},
  {path: 'page-forgot-password', component: ForgotPasswordComponent},
  {path: 'page-error-400', component: Error400Component},
  {path: 'page-error-403', component: Error403Component},
  {path: 'page-error-404', component: Error404Component},
  {path: 'page-error-500', component: Error500Component},
  {path: 'page-error-503', component: Error503Component},


  {path: '**', component: Error404Component},


];

@NgModule({
  imports: [RouterModule.forRoot(routes, {scrollPositionRestoration: 'enabled'})],
  exports: [RouterModule]
})
export class AppRoutingModule {
}
