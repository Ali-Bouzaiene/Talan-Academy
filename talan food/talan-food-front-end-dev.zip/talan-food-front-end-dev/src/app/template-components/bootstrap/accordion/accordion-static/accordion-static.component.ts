import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-accordion-static',
  templateUrl: './accordion-static.component.html',
  styleUrls: ['./accordion-static.component.css']
})
export class AccordionStaticComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
