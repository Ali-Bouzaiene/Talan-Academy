import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-nav-markup',
  templateUrl: './nav-markup.component.html',
  styleUrls: ['./nav-markup.component.css']
})
export class NavMarkupComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
