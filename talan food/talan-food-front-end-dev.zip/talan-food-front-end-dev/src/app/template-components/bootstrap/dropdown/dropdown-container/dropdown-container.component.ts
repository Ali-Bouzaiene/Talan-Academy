import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dropdown-container',
  templateUrl: './dropdown-container.component.html',
  styleUrls: ['./dropdown-container.component.css']
})
export class DropdownContainerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
