export class MenuDay {

    id!:number;
    date!:Date;
    listProducts!:any[];
 
}