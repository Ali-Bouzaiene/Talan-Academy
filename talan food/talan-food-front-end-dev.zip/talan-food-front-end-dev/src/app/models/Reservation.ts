import { User } from "../template-components/material/dzmt-autocomplete/dzmt-autocomplete-display/dzmt-autocomplete-display.component";

export class Reservation {


	 id!: number;
	price!: number;
	user ! : User;
	date!:Date;
	
 
}