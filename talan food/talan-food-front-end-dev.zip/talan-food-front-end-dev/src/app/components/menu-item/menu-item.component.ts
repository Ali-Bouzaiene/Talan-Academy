import {Component, EventEmitter, Input, OnInit, Output} from '@angular/core';

@Component({
  selector: 'app-menu-item',
  templateUrl: './menu-item.component.html',
  styleUrls: ['./menu-item.component.css']
})
export class MenuItemComponent implements OnInit {
  @Input() item: any;
  @Output() newItemEvent = new EventEmitter<any>();
  product = {
    id: '',
    quantity: 0,
    price: ''
  };
  quantity: any = 0;
  constructor() { }

  ngOnInit(): void {
  }

  onIncrement(id: any, price: any) {
    if (this.product.quantity < this.item.quantity) {
      this.quantity++;
    }
    this.product.id = id;
    this.product.quantity = this.quantity;
    this.product.price = price;
    this.newItemEvent.emit(this.product);
  }

  onDecrement(id: any, price: any) {
    if (this.quantity > 0) {
      this.quantity--;
      this.product.id = id;
      this.product.quantity = this.quantity;
      this.product.price = price;
      this.newItemEvent.emit(this.product);
    }
  }
}
