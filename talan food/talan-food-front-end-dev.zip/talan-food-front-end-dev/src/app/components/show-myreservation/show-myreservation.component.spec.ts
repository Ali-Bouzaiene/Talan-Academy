import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ShowMyreservationComponent } from './show-myreservation.component';

describe('ShowMyreservationComponent', () => {
  let component: ShowMyreservationComponent;
  let fixture: ComponentFixture<ShowMyreservationComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ShowMyreservationComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ShowMyreservationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
