import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Reservation } from 'src/app/models/Reservation';
import { AuthenticationService } from 'src/app/services/authentication.service';
import { ReservationService } from 'src/app/services/reservation.service';
import Swal from 'sweetalert2';
import {DatePipe} from "@angular/common";


@Component({
  selector: 'app-show-myreservation',
  templateUrl: './show-myreservation.component.html',
  styleUrls: ['./show-myreservation.component.css'],
  providers: [DatePipe]

})

export class ShowMyreservationComponent implements OnInit {
  reservation! : Reservation[];
  resultAnnulation!:any;
  myDate!: any;


  constructor(private reservationService : ReservationService , private router:Router , private authenticationService : AuthenticationService , private datePipe: DatePipe) { }

  ngOnInit(): void {
    this.getAllResrvationByUserId(this.authenticationService.getUserFromLocalCache().id)
    this.myDate = this.datePipe.transform(new Date(), 'yyyy-MM-dd');

  }


  getAllResrvationByUserId(idUser : number){
    this.reservationService.getReservationByUserId(idUser).subscribe(data => {this.reservation=data;
    console.log(this.reservation);});

  }

  deleteReservationById(id:number){
    this.reservationService.deleteReservationById(id).subscribe(data=>{this.resultAnnulation=data;
      console.log(this.resultAnnulation);
      this.getAllResrvationByUserId(this.authenticationService.getUserFromLocalCache().id)
    });
  };


  showReservationDetails(id:number){
    this.router.navigate([`/ordersreservation`,id]);
  }

  annulerReservation(reservId :number){
    const Toast = Swal.mixin({

      toast: true,

      position: 'top-end',

      showConfirmButton: false,

      timer: 2000,

      timerProgressBar: true,

      didOpen: (toast) => {

        toast.addEventListener('mouseenter', Swal.stopTimer)

        toast.addEventListener('mouseleave', Swal.resumeTimer)

      }

    })

   

    Toast.fire({

      icon: 'success',

      title: ' Traitement en cours'

    })
    this.reservationService.deleteReservationById(reservId).subscribe(data=>{this.resultAnnulation=data;
      console.log(data);
      

      if(this.resultAnnulation==true){
        this.getAllResrvationByUserId(this.authenticationService.getUserFromLocalCache().id)

        const Toast = Swal.mixin({
          toast: true,
          position: 'top-end',
          showConfirmButton: false,
          timer: 3000,
          timerProgressBar: true,
          didOpen: (toast) => {
            toast.addEventListener('mouseenter', Swal.stopTimer)
            toast.addEventListener('mouseleave', Swal.resumeTimer)
          }
        })
        Toast.fire({
          icon: 'success',
          title: ' Reservation annulée avec succès'
        })
      }else{
    
        const Toast = Swal.mixin({
          toast: true,
          position: 'top-end',
          showConfirmButton: false,
          timer: 3000,
          timerProgressBar: true,
          didOpen: (toast) => {
            toast.addEventListener('mouseenter', Swal.stopTimer)
            toast.addEventListener('mouseleave', Swal.resumeTimer)
          }
        })
        Toast.fire({
          icon: 'warning',
          title: ' Vous ne pouvez pas annuler votre reservation avant les 24h ! '
        })
      }
    });

  }
  








}
