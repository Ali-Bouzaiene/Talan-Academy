import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ShowAllReservationsComponent } from './show-all-reservations.component';

describe('ShowAllReservationsComponent', () => {
  let component: ShowAllReservationsComponent;
  let fixture: ComponentFixture<ShowAllReservationsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ShowAllReservationsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ShowAllReservationsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
