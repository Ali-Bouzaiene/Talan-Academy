import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ProductService } from 'src/app/services/product.service';

@Component({
  selector: 'app-order-product-card',
  templateUrl: './order-product-card.component.html',
  styleUrls: ['./order-product-card.component.css']
})
export class OrderProductCardComponent implements OnInit {

  @Input() product! : any;
  @Output() quantityEvent = new EventEmitter<any>();
  rating : any
  order={
    id: '',
    quantity:'',
    totalPrice:0,
    reste:0
  }
  quantity:any=0;
  constructor(private activatedRoute: ActivatedRoute,private router : Router, private productService:ProductService) { }

  ngOnInit(): void {
    this.productService.getRating(this.product.id).subscribe(
      data => 
      {this.rating = data;
      console.log(data)}
      );

    this.order.id=this.product.id
   
  }
  showDetails(id : number){
    this.router.navigateByUrl(`products/${id}`);
  }
  addQuantity(){
   
    if(this.quantity<this.product.quantity){
      this.quantity++
      this.order.quantity=this.quantity
      this.order.totalPrice=this.quantity*this.product.price
      this.order.reste=this.product.quantity-this.quantity
      this.quantityEvent.emit(this.order);
 
  }
}

  removeQuantity(){
    if(this.quantity>0){
      this.quantity--
      this.order.quantity=this.quantity
      this.order.reste=this.product.quantity-this.quantity
      this.order.totalPrice=this.quantity*this.product.price
      this.quantityEvent.emit(this.order);
    }
  }

  getRating(id : any){
    this.productService.getRating(id).subscribe(data=>{ this.rating=data})
  }
}
    
