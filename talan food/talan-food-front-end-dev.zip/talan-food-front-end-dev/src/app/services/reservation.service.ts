import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ReservationService {
  baseUrl="http://localhost:8090"

  constructor(private httpclient :HttpClient) { }


  public getReservationByUserId(iduser:number): Observable<any>{
    return this.httpclient.get<any>(`${this.baseUrl}/api/reservations/GetAllByuserId/${iduser}`);
  }

  public deleteReservationById(reservationId :Number){
    return this.httpclient.delete(`${this.baseUrl}/api/reservations/annulerreseravation/${reservationId}`)

  }

  public getAllReservations(){
    return this.httpclient.get<any>(`${this.baseUrl}/api/reservations/All`)
  }

  public addReservation(reservation: any) {
    return this.httpclient.post(`${this.baseUrl}/api/reservations/Add`, reservation);
  }

  public confirmReservation(reservation: any) {
    return this.httpclient.post(`${this.baseUrl}/api/reservations/confirmReservation`, reservation);
  }

  public getAllReservationByDate(date:any){
    let params = new HttpParams();
    params = params.append('date', date);
    return this.httpclient.get<any>(`${this.baseUrl}/api/reservations/AllByDate`,{params: params})
  }

 
}
