package com.talan.food.services;

import java.util.List;

import com.talan.food.dto.OrderDto;


public interface OrderService {
	
	public List<OrderDto> getAllOrders ();
	public OrderDto findOrderById (Long id);
	public OrderDto addOrder(OrderDto order);
	public void deleteOrder (Long id);
	public List<OrderDto> getByResrvationId (Long id);


}
