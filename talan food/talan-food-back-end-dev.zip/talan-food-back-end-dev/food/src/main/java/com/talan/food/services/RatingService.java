package com.talan.food.services;



import com.talan.food.dto.RatingDto;


public interface RatingService {
	public double getRating (Long id);
	public RatingDto addRating(RatingDto rating);

}
