package com.talan.food.repositories;

import java.time.LocalDate;
import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.talan.food.entities.MenuDay;
import com.talan.food.entities.Product;

@Repository
public interface MenuRepo extends  JpaRepository<MenuDay,Long> {

	MenuDay findByDate(LocalDate date);
	
	List<MenuDay> findAllByOrderByDate();
}
