package com.talan.food.dto;

import java.util.Date;

import com.talan.food.entities.Category;

public class ProductDto {

	private Long id;
	private String name;
	private String description;
	private int quantity;
	private double price;
	private String image;
	private boolean displayed;
	private Category category;

	public ProductDto() {
		super();
	}

	public ProductDto(String name, String description, int quantity, double price, String image, boolean displayed,
			Category category) {
		super();
		this.name = name;
		this.description = description;
		this.quantity = quantity;
		this.price = price;
		this.image = image;
		this.displayed = displayed;
		this.category = category;
	}

	public ProductDto(Long id, String name, String description, int quantity, double price, String image,
			boolean displayed, Category category) {
		super();
		this.id = id;
		this.name = name;
		this.description = description;
		this.quantity = quantity;
		this.price = price;
		this.image = image;
		this.displayed = displayed;
		this.category = category;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public String getImage() {
		return image;
	}

	public void setImage(String image) {
		this.image = image;
	}

	public boolean isDisplayed() {
		return displayed;
	}

	public void setDisplayed(boolean displayed) {
		this.displayed = displayed;
	}

	public Category getCategory() {
		return category;
	}

	public void setCategory(Category category) {
		this.category = category;
	}

	@Override
	public String toString() {
		return "ProductDto [id=" + id + ", name=" + name + ", description=" + description + ", quantity=" + quantity
				+ ", price=" + price + ", image=" + image + ", displayed=" + displayed + ", category=" + category + "]";
	}

}
