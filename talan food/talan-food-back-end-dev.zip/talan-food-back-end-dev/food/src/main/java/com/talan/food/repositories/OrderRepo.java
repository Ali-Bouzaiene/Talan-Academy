package com.talan.food.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.talan.food.entities.Order;

public interface OrderRepo extends JpaRepository<Order, Long> {

	public List<Order> findOrderByReservationId (Long id);


}
