package com.talan.food.servicesImpl;


import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.talan.food.dto.RatingDto;
import com.talan.food.entities.Product;
import com.talan.food.entities.Rating;
import com.talan.food.entities.User;
import com.talan.food.helpers.ModelMapperConverter;
import com.talan.food.repositories.ProductRepo;
import com.talan.food.repositories.RatingRepo;
import com.talan.food.repositories.UserRepo;
import com.talan.food.services.RatingService;

@Service
public class RatingServiceImpl implements RatingService {
	@Autowired
	RatingRepo ratingRepo;
	@Autowired
	ProductRepo productRepo;
	@Autowired
	UserRepo userRepo;
	
	

	@Override
	public double getRating(Long id) {
		double rate=0;
		Optional<Product> product=productRepo.findById(id);
		if(product != null) {
			List<Rating> rating = ratingRepo.findByProduct(product.get());
			for (int i = 0 ; i < rating.size(); i++ ) {
				  rate=rate+rating.get(i).getValue();
				}
			rate=rate/rating.size();
			
		}
		return rate;
	}

	@Override
	public RatingDto addRating(RatingDto rating) {
		Optional<User> optionalUser=userRepo.findById(rating.getUser().getId());
		Optional<Product> optionalProduct = productRepo.findById(rating.getProduct().getId());
		rating.setUser(optionalUser.get());
		rating.setProduct(optionalProduct.get());
		
		return ModelMapperConverter.map(ratingRepo.save(ModelMapperConverter.map(rating, Rating.class)), RatingDto.class);
		
	}


}
