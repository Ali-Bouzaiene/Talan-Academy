package com.talan.food.entities;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

@Entity
public class Rating {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	private double value;
	@ManyToOne (cascade = CascadeType.MERGE)
	@OnDelete(action = OnDeleteAction.CASCADE)
	@JoinColumn(name = "userId")
	private User user;
	@ManyToOne (cascade = CascadeType.MERGE)
	@OnDelete(action = OnDeleteAction.CASCADE)
	@JoinColumn(name = "productId")
	private Product product;
	
	public Rating() {
		super();
	}



	public Rating(double value, User user, Product product) {
		
		this.setValue(value);
		this.user = user;
		this.product = product;
	}
	
	



	public Rating(Long id, double value, User user, Product product) {
		super();
		this.id = id;
		this.setValue(value);
		this.user = user;
		this.product = product;
	}



	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public Product getProduct() {
		return product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}



	public double getValue() {
		return value;
	}



	public void setValue(double value) {
		this.value = value;
	}



	@Override
	public String toString() {
		return "Rating [id=" + id + ", value=" + value + ", user=" + user + ", product=" + product + "]";
	}
	
	
	
}
