package com.talan.food.dto;

import com.talan.food.entities.Product;
import com.talan.food.entities.Reservation;

public class OrderDto {

	private Long id;	
	private  Product product;
	private int quantity;
	private  Reservation reservation;
	
	
	public OrderDto() {
		super();
	}
	public OrderDto(Long id, Product product, int quantity, Reservation reservation) {
		super();
		this.id = id;
		this.product = product;
		this.quantity = quantity;
		this.reservation = reservation;
	}
	
	public OrderDto(Product product, int quantity, Reservation reservation) {
		super();
		this.product = product;
		this.quantity = quantity;
		this.reservation = reservation;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Product getProduct() {
		return product;
	}
	public void setProduct(Product product) {
		this.product = product;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public Reservation getReservation() {
		return reservation;
	}
	public void setReservation(Reservation reservation) {
		this.reservation = reservation;
	}
	@Override
	public String toString() {
		return "OrderDto [id=" + id + ", product=" + product + ", quantity=" + quantity + ", reservation=" + reservation
				+ "]";
	}
	
	
	
}
