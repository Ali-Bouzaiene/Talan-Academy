package com.talan.food.entities;


import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;




@Entity
public class MenuDay  {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	//@Temporal(TemporalType.DATE)
	private LocalDate date;
	@ManyToMany (fetch = FetchType.EAGER  /** , cascade = { CascadeType.ALL } */)
	@JoinTable(name = "menu_products", joinColumns = { @JoinColumn(name = "menu_id") }, inverseJoinColumns = {@JoinColumn(name = "product_id") })
	private List<Product> listProducts = new ArrayList<>();
	
	
	public MenuDay() {
		super();
	}
	
	public MenuDay(LocalDate date, List<Product> listProducts) {
		super();
		this.date = date;
		this.listProducts = listProducts;
	}
	
	public MenuDay(Long id, LocalDate date, List<Product> listProducts) {
		super();
		this.id = id;
		this.date = date;
		this.listProducts = listProducts;
	}

	
	public Long getId() {
		return id;
	}

	
	public void setId(Long id) {
		this.id = id;
	}

	
	public LocalDate getDate() {
		return date;
	}

	
	public void setDate(LocalDate date) {
		this.date = date;
	}


	public List<Product> getListProducts() {
		return listProducts;
	}

	
	public void setListProducts(List<Product> listProducts) {
		this.listProducts = listProducts;
	}

	@Override
	public String toString() {
		return "MenuDay [id=" + id + ", date=" + date + ", listProducts=" + listProducts + "]";
	}
	
	
	
	
	
	
}
