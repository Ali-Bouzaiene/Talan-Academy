package com.talan.food.services;

import com.talan.food.dto.UserDto;

public interface UserService {
    public UserDto signup(UserDto userDto);
    public UserDto getUserById(Long userId);
    public UserDto getUserByEmail(String email);
}
