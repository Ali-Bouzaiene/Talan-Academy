package com.talan.food.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.talan.food.dto.CategoryDto;

import com.talan.food.services.CategoryService;


@RestController
@RequestMapping("/api/products/categories")
public class CategoryController {
	@Autowired
	CategoryService categoryService;
	
	@GetMapping
	public List<CategoryDto> getAllCategories() {
		return categoryService.getAllCategories();
		
	}
	

	



}
