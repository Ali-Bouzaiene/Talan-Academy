package com.talan.food.dto;


import com.talan.food.entities.Product;
import com.talan.food.entities.User;

public class RatingDto {

	
	private Long id;
	private double value;
	
	private User user;

	private Product product;
	
	public RatingDto() {
		super();
	}



	public RatingDto(double value, User user, Product product) {
		super();
		this.setValue(value);
		this.user = user;
		this.product = product;
	}
	
	



	public RatingDto(Long id, double value, User user, Product product) {
		super();
		this.id = id;
		this.setValue(value);
		this.user = user;
		this.product = product;
	}



	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public Product getProduct() {
		return product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}



	public double getValue() {
		return value;
	}



	public void setValue(double value) {
		this.value = value;
	}
	
	
}