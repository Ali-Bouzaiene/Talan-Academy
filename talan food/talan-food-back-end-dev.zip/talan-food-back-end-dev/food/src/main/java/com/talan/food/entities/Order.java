package com.talan.food.entities;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;



@Entity
@Table (name = "orders")
public class Order {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;	
	@ManyToOne(cascade = {CascadeType.MERGE})
	@JoinColumn(name="productId")
	private  Product product;
	private int quantity;
	@ManyToOne(cascade = {CascadeType.MERGE})
	@JoinColumn(name = "reservationId")
	private  Reservation reservation;
	
	//constractor vide
	public Order() {
		super();
	}
	
	//constractor 
	public Order(Long id, Product product, int quantity, Reservation reservation) {
		super();
		this.id = id;
		this.product = product;
		this.quantity = quantity;
		this.reservation = reservation;
	}
	
	//constractor sans id
	public Order(Product product, int quantity, Reservation reservation) {
		super();
		this.product = product;
		this.quantity = quantity;
		this.reservation = reservation;
	}

	//getter and setter
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Product getProduct() {
		return product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public Reservation getReservation() {
		return reservation;
	}

	public void setReservation(Reservation reservation) {
		this.reservation = reservation;
	}

	@Override
	public String toString() {
		return "Order [id=" + id + ", product=" + product + ", quantity=" + quantity + ", reservation=" + reservation
				+ "]";
	}
	
	
	
}
