package com.talan.food.dto;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.stereotype.Repository;

import com.talan.food.entities.Product;


public class MenuDayDto {

	private Long id;
	private LocalDate date;
	private List<Product> listProducts;
	
	
	public MenuDayDto() {
		super();
	}
	
	public MenuDayDto(Long id, LocalDate date, List<Product> listProducts) {
		super();
		this.id = id;
		this.date = date;
		this.listProducts = listProducts;
	}
	
	public MenuDayDto(LocalDate date, List<Product> listProducts) {
		super();
		this.date = date;
		this.listProducts = listProducts;
	}

	
	public Long getId() {
		return id;
	}

	
	public void setId(Long id) {
		this.id = id;
	}

	
	public LocalDate getDate() {
		return date;
	}

	
	public void setDate(LocalDate date) {
		this.date = date;
	}

	
	public List<Product> getListProducts() {
		return listProducts;
	}

	
	public void setListProducts(List<Product> listProducts) {
		this.listProducts = listProducts;
	}

	@Override
	public String toString() {
		return "MenuDayDto [id=" + id + ", date=" + date + ", listProducts=" + listProducts + "]";
	}
	
	
}
