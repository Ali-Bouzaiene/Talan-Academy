package com.talan.food.services;


import java.time.LocalDate;
import java.util.Date;
import java.util.List;

import com.talan.food.dto.MenuDayDto;
import com.talan.food.dto.ProductDto;
import com.talan.food.entities.Product;

public interface MenuDayService {

	
	MenuDayDto saveMenuDay(MenuDayDto menu);
	
	MenuDayDto getMenuDayById(Long id);
	
	void deleteMenuDayById(Long id);
	
	List<MenuDayDto> getAllMenus();
	
	MenuDayDto addProductToMenuDay(Long prodId, Long menuId);
	
	List<Product> getMenuProducts (Long menId);
	
	MenuDayDto getMenuDayByDate(LocalDate date);
	
	
}
