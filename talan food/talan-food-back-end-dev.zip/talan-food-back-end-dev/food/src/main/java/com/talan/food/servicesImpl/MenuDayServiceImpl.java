package com.talan.food.servicesImpl;


import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.talan.food.dto.MenuDayDto;
import com.talan.food.dto.ProductDto;
import com.talan.food.entities.MenuDay;
import com.talan.food.entities.Product;
import com.talan.food.helpers.ModelMapperConverter;
import com.talan.food.repositories.MenuRepo;
import com.talan.food.services.MenuDayService;
import com.talan.food.services.ProductService;

@Service
public class MenuDayServiceImpl implements MenuDayService {

	@Autowired
	private MenuRepo menuRepo;
	
	@Autowired
	private ProductService productService;
	
/**
	@Override
	public MenuDayDto saveMenuDay(MenuDayDto menu) {
		return ModelMapperConverter.map(menuRepo.save(ModelMapperConverter.map(menu, MenuDay.class)), MenuDayDto.class);
	}
*/
	
	@SuppressWarnings("finally")
	@Override
	public MenuDayDto saveMenuDay(MenuDayDto menu) {
		
		LocalDate menuDate = menu.getDate(); 
		List<MenuDayDto> listMenus = new ArrayList<MenuDayDto>();
		listMenus = getAllMenus();
		try {
			if (listMenus.size()!=0) {
				for(int i = 0 ; i < listMenus.size() ; i++) {
					if (menuDate.equals(listMenus.get(i).getDate()) ) { 
						deleteMenuDayById(listMenus.get(i).getId());
					}	
				}
			} 
		} catch (Exception e) {
			e.fillInStackTrace();
		} finally {
			return ModelMapperConverter.map(menuRepo.save(ModelMapperConverter.map(menu, MenuDay.class)), MenuDayDto.class); 
		}
	}
	
	
	@Override
	public MenuDayDto getMenuDayById(Long id) {
		return ModelMapperConverter.map(menuRepo.findById(id), MenuDayDto.class);
	}
	
	@Override
	public List<MenuDayDto> getAllMenus() {
		return ModelMapperConverter.mapAll(menuRepo.findAllByOrderByDate(), MenuDayDto.class);
	}
	
	
	@Override
	public void deleteMenuDayById(Long id) {
		menuRepo.deleteById(id);
	}

	@Override
	@Transactional
	public MenuDayDto addProductToMenuDay(Long menuId ,Long prodId ) {
		
		ProductDto productDto =productService.getProductById(prodId);
		Product product = ModelMapperConverter.map(productDto,Product.class);
		
		MenuDay menu =menuRepo.getById(menuId);
		menu.getListProducts().add(product);
		menuRepo.save(menu);

		return ModelMapperConverter.map(menuRepo.save(menu),MenuDayDto.class);
	}

	@Override
	public List<Product> getMenuProducts(Long menuId) {
		MenuDayDto menu = ModelMapperConverter.map(menuRepo.findById(menuId), MenuDayDto.class);
		List<Product> menuProducts = menu.getListProducts();
		return menuProducts;
		
	}

	@Override
	public MenuDayDto getMenuDayByDate(LocalDate date) {
		return ModelMapperConverter.map(menuRepo.findByDate(date), MenuDayDto.class);
	}




}
