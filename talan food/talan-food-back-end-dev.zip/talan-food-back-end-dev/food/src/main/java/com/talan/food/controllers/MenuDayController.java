package com.talan.food.controllers;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.talan.food.dto.MenuDayDto;
import com.talan.food.dto.ProductDto;
import com.talan.food.services.MenuDayService;

@RestController
@RequestMapping("/api/menus")
@CrossOrigin
public class MenuDayController {

	@Autowired
	MenuDayService menuDayService;

	@PreAuthorize("hasAuthority('ADMIN')")
	@PostMapping("addmenu")
	@Transactional
	public MenuDayDto addMenu(@RequestBody MenuDayDto menu) {
		/**
		LocalDate menuDate = menu.getDate(); 
		List<MenuDayDto> listMenus = new ArrayList<MenuDayDto>();
		listMenus = menuDayService.getAllMenus();
		try {
			if (listMenus.size()!=0) {
				System.out.println(22222222);

				for(int i = 0 ; i < listMenus.size() ; i++) {
					if (menuDate.equals(listMenus.get(i).getDate()) ) { 
						System.out.println(111111111);
						menuDayService.deleteMenuDayById(listMenus.get(i).getId());
					}	
				}
			} 
		} catch (Exception e) {
			e.fillInStackTrace();
		} finally {
			return menuDayService.saveMenuDay(menu); 
		}
		*/
		return menuDayService.saveMenuDay(menu); 
	}

	@PreAuthorize("hasAuthority('ADMIN')")
	@PostMapping("/addproduct/{id}/{prodId}")
	public MenuDayDto addProductToMenu(@PathVariable("id") Long menuId, @PathVariable("prodId") Long prodId) {
		return menuDayService.addProductToMenuDay(menuId, prodId);
	}
	

	@GetMapping("/getall")
	public List<MenuDayDto> getAllMenuss() {
		return menuDayService.getAllMenus();
	}

	@GetMapping("/getmenu/{id}")
	public MenuDayDto getMenuById(@PathVariable("id") Long id) {
		return menuDayService.getMenuDayById(id);
	}

	@GetMapping("/getmenu/date")
	public MenuDayDto getMenuByDate(@RequestParam("date") @DateTimeFormat(pattern = "yyyy-MM-dd") LocalDate date) {
		return menuDayService.getMenuDayByDate(date);
	}

	@PreAuthorize("hasAuthority('ADMIN')")
	@DeleteMapping("/delete/{id}")
	public void deleteMenu(@PathVariable("id") Long id) {
		menuDayService.deleteMenuDayById(id);
	}
}
