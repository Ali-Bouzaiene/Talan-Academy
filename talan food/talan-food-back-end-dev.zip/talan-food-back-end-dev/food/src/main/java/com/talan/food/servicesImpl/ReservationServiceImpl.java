package com.talan.food.servicesImpl;

import java.time.LocalDate;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;
import com.talan.food.dto.ReservationDto;
import com.talan.food.entities.Order;
import com.talan.food.entities.Product;
import com.talan.food.entities.Reservation;
import com.talan.food.entities.User;
import com.talan.food.helpers.ModelMapperConverter;
import com.talan.food.repositories.OrderRepo;
import com.talan.food.repositories.ProductRepo;
import com.talan.food.repositories.ReservationRepo;
import com.talan.food.repositories.UserRepo;
import com.talan.food.services.ReservationService;

@Service
public class ReservationServiceImpl implements ReservationService {

	@Autowired
	ReservationRepo reservationRepo;
	@Autowired
	UserRepo userRepo;
	@Autowired
	OrderRepo orderrepo;
	@Autowired
	ProductRepo productRepo;
	@Autowired
	private JavaMailSender javaMailSender;
	
	
	
	public ReservationServiceImpl() {
	}

	@Override
	public List<ReservationDto> getAllReservation() {
		return ModelMapperConverter.mapAll(reservationRepo.findAllByOrderById(),ReservationDto.class);
	}

	@Override
	public List<ReservationDto> getReservationByDate(LocalDate date) {
		System.out.println(date);
		return ModelMapperConverter.mapAll(reservationRepo.findAllByDateOrderById(date), ReservationDto.class) ;
	}
	
	@Override
	public ReservationDto getReservationById(Long Id) {
		return ModelMapperConverter.map(reservationRepo.findById(Id), ReservationDto.class);
	}

	@Override
	public ReservationDto addReservation(ReservationDto reservationDto) {
		/******evoie par id*****/
		Optional<User> userOptional =userRepo.findById(reservationDto.getUser().getId()) ;
		reservationDto.setUser(userOptional.get());
		/******fin evoie par id*****/
		
		Reservation reservation = ModelMapperConverter.map(reservationDto,Reservation.class);
		reservationRepo.save(reservation);
		return ModelMapperConverter.map(reservation, ReservationDto.class);
		
	}

	@Override
	public ReservationDto editReservation(ReservationDto reservationDto) {
		
		
		/******evoie par id*****/
		Optional<User> userOptional =userRepo.findById(reservationDto.getUser().getId()) ;
		reservationDto.setUser(userOptional.get());
		/******fin evoie par id*****/
		
		Reservation editedReservation = ModelMapperConverter.map(reservationDto,Reservation.class);
		reservationRepo.save(editedReservation);
		
		//Debut traitement envoie Mail
		
		SimpleMailMessage sendReservation=new SimpleMailMessage();
		sendReservation.setTo("hamza.bouachir@talan.com");
		sendReservation.setText("Bonjour Gourmet ! Le collaborateur "+" "+editedReservation.getUser().getFirstName()+" "+editedReservation.getUser().getLastName()+" "+"a edité(e) sa reservation  numéro"+" "+editedReservation.getId());
		sendReservation.setSubject("Reservation pour le Collaborateur : "+editedReservation.getUser().getFirstName()+" "+editedReservation.getUser().getLastName());
		javaMailSender.send(sendReservation);
		//Fin traitement envoie Mail
		return ModelMapperConverter.map(editedReservation, ReservationDto.class);
	}

	
	@Override
	public void deleteReservationById(Long id) {
		reservationRepo.deleteById(id);
	
	}


	@Override
	public List<ReservationDto> getReservationByUserId(Long Id) {
		return  ModelMapperConverter.mapAll(reservationRepo.findByUserIdOrderByIdDesc(Id), ReservationDto.class);
	}

	
	
	
	@Override
	public ReservationDto confirmReservation(ReservationDto reservationDto) {
		
		/******evoie par id*****/
		Optional<User> userOptional =userRepo.findById(reservationDto.getUser().getId()) ;
		reservationDto.setUser(userOptional.get());
		/******fin evoie par id*****/
		
		Reservation confirmedReservation = ModelMapperConverter.map(reservationDto,Reservation.class);
		confirmedReservation.setConfirmed(true);
		reservationRepo.save(confirmedReservation);
		//Debut traitement envoie Mail lorsque l'utilisateur clique sur confirmer ma reservation apres avoir bien sur terminer tout les commandes
		SimpleMailMessage sendReservation=new SimpleMailMessage();
		sendReservation.setTo("hamza.bouachir@talan.com");
		sendReservation.setText("Bonjour Gourmet ! Le collaborateur "+" "+confirmedReservation.getUser().getFirstName()+" "+confirmedReservation.getUser().getLastName()+" "+"a passé(e) une nouvelle reservation sous le numero"+" "+confirmedReservation.getId());
		sendReservation.setSubject("Reservation pour le collaborateur : "+confirmedReservation.getUser().getFirstName()+" "+confirmedReservation.getUser().getLastName());
		javaMailSender.send(sendReservation);
		//Fin traitement envoie Mail
		return ModelMapperConverter.map(confirmedReservation, ReservationDto.class);
     }

	
	
	
	
	@Override
	public boolean annulerReservation(Long id) {
		boolean result=false;
		Reservation reservationAnnuler =reservationRepo.getById(id);
		LocalDate dateInitiale = reservationAnnuler.getDate();
		LocalDate actualDate = LocalDate.now();
		
		if((actualDate.isBefore(dateInitiale.minusDays(1)) )) {
			 List<Order> orders = orderrepo.findOrderByReservationId(id) ;
            for(int i=0 ; i<orders.size();i++) {
            	int annuledquatitity = orders.get(i).getQuantity();
            	int disponibleQuantity  = orders.get(i).getProduct().getQuantity();
            	int newquantity = disponibleQuantity +annuledquatitity;
            	Product p = orders.get(i).getProduct();
            	productRepo.getById(p.getId()).setQuantity(newquantity);
            	orderrepo.deleteById(orders.get(i).getId());

            }
			SimpleMailMessage annulerReservation=new SimpleMailMessage();
			annulerReservation.setTo("hamza.bouachir@talan.com");
			annulerReservation.setSubject("Annulation de la réservation du collaborateur : "+reservationAnnuler.getUser().getFirstName()+" "+reservationAnnuler.getUser().getLastName());
			annulerReservation.setText("Bonjour Gourmet ! Le collaborateur "+" "+reservationAnnuler.getUser().getFirstName()+" "+reservationAnnuler.getUser().getLastName()+" "+"a annulé(e) la réservation numéro "+" "+reservationAnnuler.getId()+" "+"prévue pour le "+" "+reservationAnnuler.getDate());
			reservationRepo.delete(reservationAnnuler);
			javaMailSender.send(annulerReservation);

			result=true;
		}
		else {
			result=false;
		}
		
		return result;
	}
	
	
	


	
	
	

	

}
