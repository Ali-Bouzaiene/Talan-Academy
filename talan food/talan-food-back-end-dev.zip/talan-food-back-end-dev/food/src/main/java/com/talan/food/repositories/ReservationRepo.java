package com.talan.food.repositories;

import java.time.LocalDate;
import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.talan.food.entities.Reservation;

@Repository
public interface ReservationRepo extends JpaRepository<Reservation, Long> {
	
	List<Reservation> findByUserIdOrderByIdDesc(Long id);
	List<Reservation> findAllByOrderById();
	List<Reservation> findAllByDateOrderById(LocalDate date);
	

}
