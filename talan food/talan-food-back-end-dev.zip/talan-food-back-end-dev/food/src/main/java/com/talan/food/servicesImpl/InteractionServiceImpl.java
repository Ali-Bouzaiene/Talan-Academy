package com.talan.food.servicesImpl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

import com.talan.food.dto.InteractionDto;
import com.talan.food.entities.Interaction;
import com.talan.food.entities.User;
import com.talan.food.helpers.ModelMapperConverter;
import com.talan.food.repositories.InteractionRepo;
import com.talan.food.repositories.UserRepo;
import com.talan.food.services.InteractionService;

@Service
public class InteractionServiceImpl implements InteractionService {

    @Autowired
	private InteractionRepo interactionRepo ;
	@Autowired
	UserRepo userRepo;
	@Autowired
	private JavaMailSender javaMailSender;

	@Override
	public List<InteractionDto> getAllInteraction() {
		return ModelMapperConverter.mapAll(interactionRepo.findAllByOrderById(), InteractionDto.class );
	}

	@Override
	public InteractionDto getInteractionById(Long Id) {
		return ModelMapperConverter.map(interactionRepo.findById(Id), InteractionDto.class);
	}

	@Override
	public InteractionDto addInteraction(InteractionDto interactionDto) {
		
		/******evoie par id*****/
		Optional<User> userOptional =userRepo.findById(interactionDto.getUser().getId()) ;
		interactionDto.setUser(userOptional.get());
		/******fin evoie par id*****/
		
	Interaction interaction = ModelMapperConverter.map(interactionDto, Interaction.class);
	interactionRepo.save(interaction);
	//Debut traitement envoie Mail
			SimpleMailMessage sendInteraction=new SimpleMailMessage();
			sendInteraction.setTo("hamza.bouachir@talan.com");
			sendInteraction.setText("Bonjour Gourmet ! Le collaborateur "+" "+interaction.getUser().getFirstName()+" "+interaction.getUser().getLastName()+" "+"a posté(e) une nouvelle"+" "+interaction.getType()+" " + "sous le numéro"+" "+interaction.getId());
			sendInteraction.setSubject("Nouvelle : "+" "+interaction.getType()+""+"de la part du collaborateur"+" "+interaction.getUser().getFirstName()+" "+interaction.getUser().getLastName());
			javaMailSender.send(sendInteraction);
   //Fin traitement envoie Mail
	 
		return ModelMapperConverter.map(interaction, InteractionDto.class);
	}

	@Override
	public void deleteInteractionById(Long id) {
		interactionRepo.deleteById(id);

	}
	
	@Override
	public void answerReclamationsClient(Long interactionId  , String message ) {
		SimpleMailMessage ClientResponse=new SimpleMailMessage();
		System.out.println(message);
		System.out.println(interactionId);

		Interaction  interaction = interactionRepo.getById(interactionId);
		ClientResponse.setTo(interaction.getUser().getEmail());
		ClientResponse.setSubject("Reponse suite a votre reclamation N° "+" "+interaction.getId() );
		ClientResponse.setText(message);
		javaMailSender.send(ClientResponse);

		
	}
	
	
	public void answerToSuggession(Long interactionId ) {
		Interaction  interaction = interactionRepo.getById(interactionId);
		SimpleMailMessage SuugessionResponse=new SimpleMailMessage();
		SuugessionResponse.setTo(interaction.getUser().getEmail());
		SuugessionResponse.setSubject("Acceptation de votre suggestion N° "+" "+interaction.getId() );
		SuugessionResponse.setText("Felicitaions, Votre suggestion du produit"+" "+interaction.getDescription()+" "+"est approuvée !");
		javaMailSender.send(SuugessionResponse);

	}
	
	
	@Override
	public List<InteractionDto> getInteractionByReclamation() {
		String reclamation = "Reclamation";
		return ModelMapperConverter.mapAll(interactionRepo.findAllByTypeOrderByIdDesc(reclamation), InteractionDto.class );
	}
	
	@Override
	public List<InteractionDto> getInteractionBySuggestion() {
		String reclamation = "Suggestion";
		return ModelMapperConverter.mapAll(interactionRepo.findAllByTypeOrderByIdDesc(reclamation), InteractionDto.class );
	}

	
	@Override
	public List<InteractionDto> getInteractionByNote() {
		String note = "Note";
		return ModelMapperConverter.mapAll(interactionRepo.findAllByTypeOrderByIdDesc(note), InteractionDto.class );
	}

	

}
