package com.talan.food.controllers;

import java.time.LocalDate;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.talan.food.dto.ReservationDto;
import com.talan.food.services.ReservationService;

@RestController
@RequestMapping("/api/reservations")
public class ReservationController {

	@Autowired
	private ReservationService reservationService;

	public ReservationController() {
	}

	@PreAuthorize("hasAuthority('ADMIN')")
	@GetMapping("/All")
	public List<ReservationDto> getAllReservation() {
		return reservationService.getAllReservation();

	}

	@PreAuthorize("hasAuthority('ADMIN')")
	@GetMapping("AllByDate")
	public List<ReservationDto> getAllReservationsByDate(
			@RequestParam("date") @DateTimeFormat(pattern = "yyyy-MM-dd") LocalDate date) {
	
		return reservationService.getReservationByDate(date);

	}

	@PreAuthorize("hasAnyAuthority('ADMIN', 'USER')")
	@GetMapping("/GetAllById/{id}")
	public ReservationDto getAllReservationById(@PathVariable("id") Long id) {
		return reservationService.getReservationById(id);

	}

	@PreAuthorize("hasAuthority('USER')")
	@GetMapping("/GetAllByuserId/{iduser}")
	public List<ReservationDto> getAllReservationByUserId(@PathVariable(name = "iduser") Long iduser) {
		return reservationService.getReservationByUserId(iduser);

	}

	@PreAuthorize("hasAuthority('USER')")
	@PostMapping("/Add")
	public ReservationDto addReservation(@RequestBody ReservationDto reservationDto) {
		return reservationService.addReservation(reservationDto);

	}

	@PreAuthorize("hasAuthority('USER')")
	@PostMapping("/Edit")
	public ReservationDto editReservation(@RequestBody ReservationDto reservationDto) {
		return reservationService.editReservation(reservationDto);

	}

	@PreAuthorize("hasAnyAuthority('USER', 'ADMIN')")
	@DeleteMapping("/delete/{id}")
	public void deleteReservation(@PathVariable("id") Long id) {
		reservationService.deleteReservationById(id);
	}

	@PreAuthorize("hasAuthority('USER')")
	@PostMapping("confirmReservation")
	public boolean confirmReservation(@RequestBody ReservationDto reservationDto) {
		ReservationDto reservation = reservationService.confirmReservation(reservationDto);
		return reservation != null;
	}

	@PreAuthorize("hasAuthority('USER')")
	@DeleteMapping("annulerreseravation/{id}")
	public boolean annulReservation(@PathVariable ("id") Long id) {
		
		return reservationService.annulerReservation(id);
	}

}
