package com.talan.food.repositories;


import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.talan.food.entities.Category;
import com.talan.food.entities.Product;

@Repository
public interface ProductRepo extends  JpaRepository<Product, Long> {

	List<Product> findAllByOrderById();
	
	
	@Query("select p from Product p where p.category = ?1")
	List<Product> findProductsByCategory(Category category);
	
	
	List<Product> findByCategoryOrderByIdAsc(Category cat);
	
	
	List<Product> findByCategoryIdOrderByIdAsc(Long id);
	
}
