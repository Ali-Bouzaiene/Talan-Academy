package com.talan.food.servicesImpl;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.transaction.annotation.Transactional;

import com.talan.food.dto.MenuDayDto;
import com.talan.food.dto.ProductDto;
import com.talan.food.entities.Product;
import com.talan.food.helpers.ModelMapperConverter;


@SpringBootTest
public class MenuDayServiceImplTest {
	
	@Autowired
	MenuDayServiceImpl menuDayServiceImpl;
	
	@Autowired
	ProductServiceImpl productServiceImpl;
	

	
	@Test 
	void testSaveMenuDay() throws Exception{
		
		MenuDayDto menu = new MenuDayDto();
		
		LocalDate date = LocalDate.now();
		
		
		Product prod1 =  new Product();
		prod1.setName("chappati");
		Product prod2 =  new Product();
		prod2.setName("tajine ");
		List<Product> listProducts = new ArrayList<>();
		listProducts.add(prod1);
		listProducts.add(prod2);
		menu.setListProducts(listProducts);
		
		menu.setDate(date);
		
		assertEquals(menuDayServiceImpl.saveMenuDay(menu).getId(), 4);	
	}
	
	
	@Test 
	void testGetMenuDayById() throws Exception{
		assertEquals(menuDayServiceImpl.getMenuDayById(2L).getId(),2);
	}
	
	@Test 
	void testGetMenuDayByDate() throws Exception{
		LocalDate date = LocalDate.now();
		assertEquals(menuDayServiceImpl.getMenuDayByDate(date).getId(),16);
	}
	
	@Test 
	void testGetMenuProducts() throws Exception{
		assertEquals(menuDayServiceImpl.getMenuProducts(1L).get(0).getId(),9);
	}

	
	@Test 
	void testAddProductToMenuDay() throws Exception{
		assertEquals(menuDayServiceImpl.addProductToMenuDay(1L, 2L).getListProducts().size(),2);
	}
}
