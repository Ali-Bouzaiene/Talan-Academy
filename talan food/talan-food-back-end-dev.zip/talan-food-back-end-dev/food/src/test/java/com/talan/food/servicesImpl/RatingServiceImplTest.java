package com.talan.food.servicesImpl;

import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;


import com.talan.food.dto.RatingDto;
import com.talan.food.entities.Product;
import com.talan.food.entities.User;

@SpringBootTest
@AutoConfigureMockMvc
public class RatingServiceImplTest {
	
	
	@Autowired
	RatingServiceImpl ratingServiceImpl;
	
	@Test
	public void getRatingTest() throws Exception {
	
	assertEquals(ratingServiceImpl.getRating(4L), 5);

	}
	
	@Test
	public void addRatingTest() throws Exception {
		User user = new User ();
		Product product = new Product();
		user.setId(1L);
		product.setId(2L);
		RatingDto ratingDto = new RatingDto(3,user,product);
		
	
	assertEquals(ratingServiceImpl.addRating(ratingDto).getProduct(), ratingDto.getProduct());
	assertEquals(ratingServiceImpl.addRating(ratingDto).getUser(), ratingDto.getUser());

	}

}
