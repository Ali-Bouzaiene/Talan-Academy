package com.talan.food.controllers;

import static org.hamcrest.CoreMatchers.is;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.Date;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.web.servlet.MockMvc;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.talan.food.dto.ProductDto;
import com.talan.food.entities.Category;

@SpringBootTest
@AutoConfigureMockMvc
public class ProductControllerTest {

	@Autowired
	private MockMvc mockMvc;

	@Test
	void testAddProduct() throws Exception {
		mockMvc.perform(post("/api/products/addprod").contentType("application/json").content(asJsonString(
				new ProductDto("biscuit", "diari", 5, 1.5, "urlimage", true, new Category(2L, "mekla")))))
				.andExpect(status().isOk());
	}

	@Test
	void testGetProducts() throws Exception {
		mockMvc.perform(get("/api/products/getall")).andExpect(status().isOk())
				.andExpect(jsonPath("$[0].name", is("biscuit")));
	}

	@Test
	void testGetProductById() throws Exception {
		mockMvc.perform(get("/api/products/getprod/{id}", 11)).andExpect(status().isOk())
				.andExpect(jsonPath("$.name", is("bechkoutou")));
	}

	@Test
	void testGetProductsByCategory() throws Exception {
		Category cat = new Category(1L, "7lou");
		this.mockMvc.perform(get("/api/products/getbycategory").contentType("application/json")
				.content(asJsonString(cat))).andExpect(status().isOk());
	}


	@Test
	void testGetProductsByCategoryId() throws Exception {
		mockMvc.perform(get("/api/products/getbycatid/{catId}", 2)).andExpect(status().isOk())
				.andExpect(jsonPath("$[0].name", is("croissant")))
				.andExpect(jsonPath("$[0].name", is("croissant")));
	}

	public static String asJsonString(final Object obj) {
		try {
			return new ObjectMapper().writeValueAsString(obj);
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

}
