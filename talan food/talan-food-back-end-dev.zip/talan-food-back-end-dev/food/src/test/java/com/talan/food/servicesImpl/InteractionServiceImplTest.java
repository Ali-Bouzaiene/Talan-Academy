//package com.talan.food.servicesImpl;
//
//import static org.junit.jupiter.api.Assertions.assertEquals;
//
//import java.util.Date;
//
//import org.junit.jupiter.api.Test;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
//import org.springframework.boot.test.context.SpringBootTest;
//
//import com.talan.food.dto.InteractionDto;
//import com.talan.food.dto.ReservationDto;
//import com.talan.food.entities.User;
//
//@SpringBootTest
//@AutoConfigureMockMvc
//public class InteractionServiceImplTest {
//
//    @Autowired
//    InteractionServiceImpl InteractionServiceImpl;
//
//    @Test
//    public void  testGetAllInteraction() throws Exception {
//    	assertEquals(InteractionServiceImpl.getAllInteraction().get(0).getType(),"Reclamatiotion");
//    }
//
//    @Test
//    public void  testGetInteractionById() throws Exception{
//    	assertEquals(InteractionServiceImpl.getInteractionById(2L).getType(),"Reclamatiotion");
//
//    }
//
//    @Test
//    public void testAddInteraction() throws Exception {
//
//            User user = new User("Alain", "Brader");
//        	InteractionDto interactionDto= new InteractionDto("Reclamation","quantité reduite",2, new User(1L,"Hamza", "Bouachir"));
//        	assertEquals(InteractionServiceImpl.addInteraction(interactionDto).getType(),"Reclamation");
//
//        }
//    }
//
//
//
