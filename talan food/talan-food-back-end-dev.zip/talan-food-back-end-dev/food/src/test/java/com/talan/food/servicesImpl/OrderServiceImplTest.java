//package com.talan.food.servicesImpl;
//
//
//import static org.junit.jupiter.api.Assertions.assertEquals;
//
//
//import org.junit.jupiter.api.Test;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
//import org.springframework.boot.test.context.SpringBootTest;
//
//
//import com.talan.food.dto.OrderDto;
//import com.talan.food.entities.Product;
//import com.talan.food.entities.Reservation;
//
//
//
//@SpringBootTest
//@AutoConfigureMockMvc
//public class OrderServiceImplTest {
//
//	@Autowired
//	private OrderServiceImpl orderServiceImpl;
//
//
//	@Test
//	public void testGetAllOrders() throws Exception {
//		assertEquals(orderServiceImpl.getAllOrders().get(0).getQuantity(),2);
//	}
//	@Test
//	public void testFindOrderById() throws Exception{
//		Product product = new Product(15L);
//		Reservation reservation = new Reservation(12L);
//		OrderDto orderDto = new OrderDto(2L,product,2,reservation);
//		assertEquals(orderServiceImpl.findOrderById(2L).getQuantity(), orderDto.getQuantity());
//	}
//	@Test
//	public void testAddOrder() throws Exception{
//		Product product = new Product(2L);
//		Reservation reservation = new Reservation(1L);
//		OrderDto orderDto = new OrderDto(60L,product,5,reservation);
//		assertEquals(orderServiceImpl.addOrder(orderDto).getId(), orderDto.getId());
//
//	}
//
//
//
//}
