package com.talan.food.servicesImpl;

import com.talan.food.dto.UserDto;
import com.talan.food.entities.Role;
import com.talan.food.entities.User;
import com.talan.food.helpers.ModelMapperConverter;
import com.talan.food.repositories.RoleRepo;
import com.talan.food.repositories.UserRepo;
import com.talan.food.services.UserService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.security.crypto.password.PasswordEncoder;

import static org.assertj.core.api.AssertionsForClassTypes.assertThat;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;


@ExtendWith(MockitoExtension.class)
class UserServiceImplTest {
    @Mock
    private UserRepo userRepo;
    @Mock
    private RoleRepo roleRepo;
    private UserService userService;
    @Mock
    private PasswordEncoder passwordEncoder;

    @BeforeEach
    void setUp() {
        this.userService = new UserServiceImpl(this.userRepo, this.roleRepo, this.passwordEncoder);
    }

    @Test
    void canSignup() {
//        given
        Role role = new Role();
        role.setId(2L);
        UserDto userDto = new UserDto("Foulen", "Ben Falten", "foulen@gmail.com", "foulenbenfalten", "21001920", role);
//        when
        userService.signup(userDto);
        User user = ModelMapperConverter.map(userDto, User.class);
//        then
        ArgumentCaptor<User> argumentCaptor = ArgumentCaptor.forClass(User.class);
        verify(userRepo).save(argumentCaptor.capture());
        assertThat(argumentCaptor.getValue().toString()).hasToString(user.toString());
    }

    @Test
    void canGetUserById() {
        //        given
        Long id = 7L;
//        when
        userService.getUserById(id);
//        then
        verify(userRepo).findById(id);
    }

    @Test
    void canGetUserByEmail() {
        //        given
        String email = "foulen@gmail.com";
//        when
        when(userService.getUserByEmail(email)).thenThrow(new NullPointerException());
        userService.getUserByEmail(email);
//        then
        verify(userRepo).findByEmail(email);
    }
}
