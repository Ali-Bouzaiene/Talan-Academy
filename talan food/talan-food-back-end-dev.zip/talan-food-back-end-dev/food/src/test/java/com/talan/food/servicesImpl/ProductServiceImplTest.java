package com.talan.food.servicesImpl;

import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.talan.food.entities.Category;

@SpringBootTest
public class ProductServiceImplTest {

	@Autowired
	ProductServiceImpl productServiceImpl;

	@Test
	void testGetProductById() throws Exception {
		assertEquals(productServiceImpl.getProductById(7L).getName(), "croissant");
	}

	@Test
	void testGetAllProducts() throws Exception {
		assertEquals(productServiceImpl.getAllProducts().get(3).getName(), "bechkoutou");
	}

	@Test
	void testGetByCategoryId() throws Exception {
		assertEquals(productServiceImpl.getByCategoryId(2L).get(0).getName(), "croissant");
	}
	
	@Test
	void testGetProductsByCategory() throws Exception {
		Category cat = new Category(1L,"7lou");
		assertEquals(productServiceImpl.getProductsByCategory(cat).get(0).getName(), "chicha");
	}
	 
}
