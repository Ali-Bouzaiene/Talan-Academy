package com.talan.food.controllers;

import static org.hamcrest.CoreMatchers.is;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.web.servlet.MockMvc;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.talan.food.dto.RatingDto;
import com.talan.food.entities.Product;
import com.talan.food.entities.User;

@SpringBootTest
@AutoConfigureMockMvc
public class RatingControllerTest {

	@Autowired
	private MockMvc mockMvc;

	@Test
	public void addRating() throws Exception {
		User user = new User();
		Product product = new Product();
		user.setId(1L);
		product.setId(1L);
	
	    this.mockMvc.perform(post("/api/products/ratings")
                .contentType("application/json")
                .content(asJsonString((new RatingDto(4,user,product)))))
        .andExpect(status().isOk());
	}
	@Test
	public void getRating() throws Exception {
		mockMvc.perform(get("/api/products/ratings/{id}", 1)).andExpect(status().isOk());
				
	}
	public static String asJsonString(final Object obj) {
	    try {
	        return new ObjectMapper().writeValueAsString(obj);
	    } catch (Exception e) {
	        throw new RuntimeException(e); 
	    }
	}
}