//package com.talan.food.controllers;
//
//import static org.hamcrest.CoreMatchers.is;
//import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
//import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
//import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
//import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
//
//import org.junit.jupiter.api.Test;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
//import org.springframework.boot.test.context.SpringBootTest;
//import org.springframework.test.web.servlet.MockMvc;
//
//import com.fasterxml.jackson.databind.ObjectMapper;
//import com.talan.food.dto.OrderDto;
//import com.talan.food.entities.Product;
//import com.talan.food.entities.Reservation;
//
//
//@SpringBootTest
//@AutoConfigureMockMvc
//public class OrderControllerTest {
//	@Autowired
//	private MockMvc mockMvc;
//	@Test
//	public void testGetAllOrders() throws Exception {
//		mockMvc.perform(get("/api/ordres"))
//		.andExpect(status().isOk())
//		.andExpect( jsonPath("$[0].quantity", is(2)));
//	}
//	@Test
//	public void testFindOrderById() throws Exception {
//		mockMvc.perform(get("/api/ordres/{id}", 2))
//		.andExpect(status().isOk())
//		.andExpect( jsonPath("quantity", is(2)));
//	}
//
//	@Test
//	public void testAddOrder() throws Exception{
//		mockMvc.perform(post("/api/ordres").contentType("application/json").content(asJsonString(new OrderDto(new Product(1L),4,new Reservation(2L)))))
//		.andExpect(status().isOk());
//	}
//
//	public static String asJsonString(final Object obj) {
//	    try {
//	        return new ObjectMapper().writeValueAsString(obj);
//	    } catch (Exception e) {
//	        throw new RuntimeException(e);
//	    }
//	}
//
//
//
//}
